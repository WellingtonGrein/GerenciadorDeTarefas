package com.example.demo.util;

public enum NivelDeAcesso {
    VISUALIZADOR, EDITOR, ADMINISTRADOR
}
